import UIKit
import CoreLocation


class ViewController: UIViewController, UITextFieldDelegate, CLLocationManagerDelegate, UISearchBarDelegate {
    
    
    
    private func parseWeatherResponse(data: Data) -> WeatherResponse? {
        let decoder = JSONDecoder()
        var weather: WeatherResponse?
        
        do {
            weather = try decoder.decode(WeatherResponse.self, from: data)
        } catch {
            print("Error Decoding")
        }
        
        return weather
    }
    
    
    
    private func parseJson(data: Data) -> WeatherResponse? {
        let decoder = JSONDecoder()
        var weather: WeatherResponse?
        
        do {
            weather = try decoder.decode(WeatherResponse.self, from: data)
        } catch {
            print("Error Decoding")
        }
        
        return weather
    }
    
    
    private func countryCodeFromCountryName(_ countryName: String, completion: @escaping (String?) -> Void) {
        let geocoder = CLGeocoder()
        
        geocoder.geocodeAddressString(countryName) { placemarks, error in
            guard let placemark = placemarks?.first, let isoCountryCode = placemark.isoCountryCode else {
                completion(nil)
                return
            }
            
            completion(isoCountryCode)
        }
    }
    
    
    
    private func updateWeatherConditionImage(code: Int) {
        var symbolName: String
        
        let weatherData = [
            1000: ["day": "sun.max", "night": "moon.stars"],
            1003: ["day": "cloud.sun", "night": "cloud.moon"],
            1006: ["day": "cloud", "night": "cloud"],
            1009: ["day": "cloud", "night": "cloud"],
            1030: ["day": "cloud.fog", "night": "cloud.fog"],
            1063: ["day": "cloud.bolt", "night": "cloud.bolt.rain"],
            1066: ["day": "cloud.snow", "night": "cloud.snow"],
            1069: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1072: ["day": "cloud.drizzle", "night": "cloud.drizzle"],
            1087: ["day": "cloud.bolt", "night": "cloud.bolt"],
            1114: ["day": "wind.snow", "night": "wind.snow"],
            1117: ["day": "wind.snow", "night": "wind.snow"],
            1135: ["day": "cloud.fog", "night": "cloud.fog"],
            1147: ["day": "cloud.fog", "night": "cloud.fog"],
            1150: ["day": "cloud.drizzle", "night": "cloud.drizzle"],
            1153: ["day": "cloud.drizzle", "night": "cloud.drizzle"],
            1168: ["day": "cloud.drizzle", "night": "cloud.drizzle"],
            1171: ["day": "cloud.drizzle", "night": "cloud.drizzle"],
            1180: ["day": "cloud.rain", "night": "cloud.rain"],
            1183: ["day": "cloud.rain", "night": "cloud.rain"],
            1186: ["day": "cloud.rain", "night": "cloud.rain"],
            1189: ["day": "cloud.rain", "night": "cloud.rain"],
            1192: ["day": "cloud.heavyrain", "night": "cloud.heavyrain"],
            1195: ["day": "cloud.heavyrain", "night": "cloud.heavyrain"],
            1198: ["day": "cloud.freezingrain", "night": "cloud.freezingrain"],
            1201: ["day": "cloud.freezingrain", "night": "cloud.freezingrain"],
            1204: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1207: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1210: ["day": "cloud.snow", "night": "cloud.snow"],
            1213: ["day": "cloud.snow", "night": "cloud.snow"],
            1216: ["day": "cloud.snow", "night": "cloud.snow"],
            1219: ["day": "cloud.snow", "night": "cloud.snow"],
            1222: ["day": "cloud.snow", "night": "cloud.snow"],
            1225: ["day": "cloud.snow", "night": "cloud.snow"],
            1237: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1240: ["day": "cloud.rain", "night": "cloud.rain"],
            1243: ["day": "cloud.heavyrain", "night": "cloud.heavyrain"],
            1246: ["day": "cloud.heavyrain", "night": "cloud.heavyrain"],
            1249: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1252: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1255: ["day": "cloud.snow", "night": "cloud.snow"],
            1258: ["day": "cloud.snow", "night": "cloud.snow"],
            1261: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1264: ["day": "cloud.sleet", "night": "cloud.sleet"],
            1273: ["day": "cloud.bolt.rain", "night": "cloud.bolt.rain"],
            1276: ["day": "cloud.bolt.heavyrain", "night": "cloud.bolt.heavyrain"],
            1279: ["day": "cloud.bolt.snow", "night": "cloud.bolt.snow"],
            1282: ["day": "cloud.bolt.heavysnow", "night": "cloud.bolt.heavysnow"]
        ]
        
        var isDaytime: Bool
        
        if let weather = weatherData[code] {
            
            let daySymbol = weather["day"] ?? "questionmark"
            let nightSymbol = weather["night"] ?? "questionmark"
            
            
            let hour = Calendar.current.component(.hour, from: Date())
            
            
            isDaytime = (hour >= 6 && hour < 18)
                    symbolName = isDaytime ? daySymbol : nightSymbol
                } else {
                    isDaytime = false // Set a default value if needed
                    symbolName = "questionmark"
                }
        
        let config = UIImage.SymbolConfiguration(paletteColors: [
            .systemBlue, .white, .black
        ])
        
        let backgroundImageName = isDaytime ? "Day" : "Night"
           view.backgroundColor = UIColor(patternImage: UIImage(named:backgroundImageName)!)
        
        weatherConditionImage.preferredSymbolConfiguration = config
        weatherConditionImage.image = UIImage(systemName: symbolName)
        
        updateTextColor(isDaytime: isDaytime)

    }
    
    
    private func updateTextColor(isDaytime: Bool) {
           let textColor: UIColor = isDaytime ? .black : .white

           temperatureLabel.textColor = textColor
           locationLabel.textColor = textColor
           WCondition.textColor = textColor
           FeelsLikeLabel.textColor = textColor
       }
    
    @IBOutlet weak var searchTextField: UISearchBar!
    
    //@IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var weatherConditionImage: UIImageView!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    
    @IBOutlet weak var CountryLabel: UILabel!
    @IBOutlet weak var ExLocationLabel: UILabel!
    @IBOutlet weak var WCondition: UILabel!
    @IBOutlet weak var TemperatureToggleSwitch: UISwitch!
    
    @IBOutlet weak var FeelsLikeLabel: UILabel!
    
    private var isTemperatureInCelsius: Bool = true
    private var weatherResponse: WeatherResponse?
    private let locationManager = CLLocationManager()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        searchTextField.delegate = self
        TemperatureToggleSwitch.isOn = false == isTemperatureInCelsius
        
        
        
        let hour = Calendar.current.component(.hour, from: Date())
                let isDaytime = (hour >= 6 && hour < 18)
                let backgroundImageName = isDaytime ? "Day" : "Night"
                view.backgroundColor = UIColor(patternImage: UIImage(named:backgroundImageName)!)

                updateTextColor(isDaytime: isDaytime)
        
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        
        textField.resignFirstResponder()
        
        onSearchTapped(UIButton())
        
        return true
    }
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if status == .denied || status == .restricted {
            
            print("Location services denied or restricted. Please enable them in Settings.")
        } else if status == .authorizedWhenInUse || status == .authorizedAlways {
            
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let first = locations.first else{
            return
        }
        print("\(first.coordinate.longitude) | \(first.coordinate.latitude)")
        let unit = isTemperatureInCelsius ? "C" : "F"
        loadWeather(search: "\(first.coordinate.latitude),\(first.coordinate.longitude)", unit: unit)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error.localizedDescription)")
    }
    
    
    private func fetchCityName(for location: CLLocation) {
        let geocoder = CLGeocoder()
        
        geocoder.reverseGeocodeLocation(location) { [weak self] placemarks, error in
            guard let self = self, let placemark = placemarks?.first else { return }
            
            
            let cityName = placemark.locality ?? "Unknown"
            DispatchQueue.main.async {
                self.searchTextField.text = cityName
            }
        }
    }
    
    
    
    
    
    @IBAction func onLocationTapped(_ sender: UIButton) {
        
        print("onlocation tapped")
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.requestLocation()
    }
    
    @IBAction func onSearchTapped(_ sender: UIButton) {
        
        let unit = isTemperatureInCelsius ? "C" : "F"
        loadWeather(search: searchTextField.text,unit: unit)
        
    }
    
    
    
    @IBAction func OnTempSwitchChanged(_ sender: UISwitch) {
        
        isTemperatureInCelsius = sender.isOn == false
        updateTemperatureLabel()
    }
    
    
    
    
    private func loadWeather(search: String?, unit: String) {
        guard let search = search else {
            return
        }
        
        // Step 1: Get URL
        guard let url = getURL(query: search, unit: unit) else {
            print("Could not get URL")
            return
        }
        
        // Step 2: Create URLSession
        let session = URLSession.shared
        
        // Step 3: Create task for the session
        let dataTask = session.dataTask(with: url) { data, response, error in
            // network call finished
            print("Network call complete")
            
            guard error == nil else {
                print("Received error")
                return
            }
            
            guard let data = data else {
                print("No Data Found")
                return
            }
            
            
            
            if let weatherResponse = self.parseJson(data: data) {
                print(weatherResponse.location.name)
                print(weatherResponse.location.region)
                print(weatherResponse.location.country)
                print(weatherResponse.current.temp_c)
                print(weatherResponse.current.temp_f)
                print(weatherResponse.current.condition)
                print(weatherResponse.current.feelslike_c)
                print(weatherResponse.current.feelslike_f)
                
                
                
                
                    DispatchQueue.main.async {
                        self.WCondition.text = weatherResponse.current.condition.text
                        self.locationLabel.text = "\(weatherResponse.location.name) ,\(weatherResponse.location.region) \n\(weatherResponse.location.country)."
                        self.temperatureLabel.text = "\(weatherResponse.current.temp_c)C"
                        self.weatherResponse = weatherResponse // Capture the response
                        self.updateTemperatureLabel()
                        self.updateWeatherConditionImage(code: weatherResponse.current.condition.code)
                        self.FeelsLikeLabel.text = "Feels Like : \(weatherResponse.current.feelslike_c)°C / \(weatherResponse.current.feelslike_f)°F"
                    }
                }
                
            }
            
            // Step 4: Start the task
            dataTask.resume()
        }
        
        private func updateTemperatureLabel() {
            guard let weatherResponse = weatherResponse else {
                print("Weather data not available")
                return
            }
            
            let temperatureValue = isTemperatureInCelsius ? "" : ""
            let temperature = isTemperatureInCelsius ? "\(weatherResponse.current.temp_c)°C" : "\(weatherResponse.current.temp_f)°F"
            self.temperatureLabel.text = "\(temperature) \(temperatureValue)"
        }
        
        private func getURL(query: String, unit: String) -> URL? {
            let baseUrl = "https://api.weatherapi.com/v1/"
            let currentEndpoint = "current.json"
            let apiKey = "d05a2c6bc585474bbb8200638231311"
            
            guard let url = "\(baseUrl)\(currentEndpoint)?key=\(apiKey)&q=\(query)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
                return nil
            }
            
            print(url)
            return URL(string: url)
        }
        
        
        
        struct WeatherResponse: Decodable {
            let location: Location
            let current: Weather
            
        }
        
        struct Location: Decodable {
            let name: String
            let region: String
            let country: String
        }
        
        struct Weather: Decodable {
            let temp_c: Float
            let temp_f: Float
            let condition: WeatherCondition
            let feelslike_c: Float
            let feelslike_f: Float
        }
        
        struct WeatherCondition: Decodable {
            let text: String
            let code: Int
        }
        
    }

